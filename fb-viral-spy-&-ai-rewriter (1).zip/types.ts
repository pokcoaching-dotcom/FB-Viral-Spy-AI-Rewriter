
export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
}

export interface ViralAnalysis {
  viralScore: number;
  hookScore: number;
  emotion: string;
  strengths: string[];
  weakness: string;
  improvement: string;
  policyWarnings: string[]; 
  grammarCheck: string;    
}

export interface FBPost {
  id: string;
  content: string;
  author: string;
  likes: number;
  comments: number;
  shares: number;
  timestamp: string;
  imageUrl?: string;
  url: string;
  analysis?: ViralAnalysis;
}

export interface LibraryItem extends FBPost {
  savedAt: string;
  tags: string[];
}

export type ViewType = 'dashboard' | 'scanner' | 'spy' | 'library' | 'ai-writer' | 'idea-bank';

export interface ScanResult {
  posts: FBPost[];
  profileName: string;
  totalEngagement: number;
  averageEngagement: number;
}

export type ScanMode = 'quick' | 'deep';
export type InputMode = 'single' | 'bulk';
export type DisplayMode = 'grid' | 'list';
export type WritingTone = 'viral' | 'professional' | 'funny' | 'storytelling' | 'urgent' | 'emotional' | 'controversial';
export type SortKey = 'total' | 'likes' | 'comments' | 'shares' | 'newest';
