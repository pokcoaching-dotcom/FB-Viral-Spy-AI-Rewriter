
import React, { useState, useEffect, useMemo } from 'react';
import { 
  LayoutDashboard, 
  Search, 
  Zap, 
  Library, 
  PenTool, 
  Menu, 
  X, 
  Facebook, 
  MessageCircle, 
  Share2, 
  ThumbsUp, 
  Bookmark, 
  Trash2, 
  Copy, 
  ChevronRight, 
  Loader2, 
  Clock, 
  Search as SearchIcon, 
  Download, 
  Info, 
  Sparkles, 
  Award, 
  AlertCircle, 
  CheckCircle, 
  Flame, 
  Database, 
  Activity, 
  List, 
  LayoutGrid, 
  ChevronLeft, 
  RotateCcw, 
  Palette, 
  Settings2, 
  History,
  LogIn,
  LogOut,
  User as UserIcon,
  ShieldCheck,
  TrendingUp,
  Cpu
} from 'lucide-react';
import { FBPost, ViewType, LibraryItem, ScanResult, ScanMode, InputMode, DisplayMode, WritingTone, SortKey, User } from './types';
import { rewritePost, analyzeViralFactor, generateViralIdeas } from './services/geminiService';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, Cell } from 'recharts';

// --- Constants ---
const ITEMS_PER_PAGE = 12;

const FORMAT_ANALYSIS_DATA = [
  { name: 'Reels', val: 1800 },
  { name: 'Story', val: 1400 },
  { name: 'Video', val: 900 },
  { name: 'Ảnh', val: 600 },
  { name: 'Text', val: 1100 }
];

const CONTENT_TEMPLATES = [
  { title: "Bí mật thành công trên Facebook 2025", content: "Chia sẻ 5 bước để bài viết của bạn đạt hàng nghìn lượt share mà không tốn 1 đồng quảng cáo...", viralReason: "Đánh vào mong muốn tăng trưởng tự nhiên", category: "Marketing" },
  { title: "Review quán cafe làm việc lý tưởng", content: "Không gian yên tĩnh, wifi mạnh, ổ điện ở khắp nơi. Đây là lựa chọn số 1 cho Freelancer...", viralReason: "Hướng tới đối tượng cụ thể là Freelancer", category: "Review" },
  { title: "Lộ trình học AI cho người không chuyên", content: "Đừng để bị đào thải bởi AI. Bắt đầu ngay với lộ trình tinh gọn này trong 7 ngày...", viralReason: "Tạo cảm giác cấp thiết (FOMO)", category: "Công nghệ" },
];

const THEME_PRESETS: Record<string, any> = {
  classic: { primary: '#2563eb', bg: '#f8fafc', text: '#0f172a', chartColors: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'] },
  midnight: { primary: '#7c3aed', bg: '#0f172a', text: '#f8fafc', chartColors: ['#8b5cf6', '#d946ef', '#ec4899', '#3b82f6', '#10b981'] },
};

const Toast: React.FC<{ message: string, type: 'success' | 'error' | 'info', onClose: () => void }> = ({ message, type, onClose }) => {
  useEffect(() => { const t = setTimeout(onClose, 3000); return () => clearTimeout(t); }, [onClose]);
  const bg = { success: 'bg-emerald-500', error: 'bg-red-500', info: 'bg-blue-500' };
  return (
    <div className={`fixed bottom-6 right-6 z-[200] ${bg[type]} text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center space-x-3 animate-in slide-in-from-bottom-5`}>
      <span className="font-bold">{message}</span>
      <button onClick={onClose} className="ml-4"><X size={16} /></button>
    </div>
  );
};

// --- Landing Page & Login Component ---
const LoginScreen: React.FC<{ onLogin: (user: User) => void }> = ({ onLogin }) => {
  const [loading, setLoading] = useState(false);

  const handleMockGoogleLogin = () => {
    setLoading(true);
    // Giả lập quá trình đăng nhập Google
    setTimeout(() => {
      onLogin({
        id: 'user_' + Math.random().toString(36).substr(2, 9),
        name: 'Người dùng Demo',
        email: 'demo@example.com',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix'
      });
      setLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-[#0f172a] flex flex-col items-center justify-center p-6 overflow-hidden relative">
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/20 blur-[120px] rounded-full"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-600/20 blur-[120px] rounded-full"></div>
      
      <div className="max-w-4xl w-full text-center space-y-8 z-10">
        <div className="inline-flex items-center space-x-2 px-4 py-2 bg-blue-500/10 border border-blue-500/20 rounded-full text-blue-400 text-xs font-black uppercase tracking-widest mb-4">
          <ShieldCheck size={14} /> <span>AI-Powered Facebook Spy Tool</span>
        </div>
        
        <h1 className="text-6xl md:text-8xl font-black text-white tracking-tighter leading-none mb-6">
          SPY <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">SMARTER</span><br/>
          POST BETTER.
        </h1>
        
        <p className="text-gray-400 text-lg md:text-xl max-w-2xl mx-auto font-medium leading-relaxed">
          Phân tích đối thủ, tìm kiếm bài viết viral và tối ưu nội dung bằng AI để thống trị bảng tin Facebook của khách hàng.
        </p>

        <div className="pt-10">
          <button 
            onClick={handleMockGoogleLogin}
            disabled={loading}
            className="group relative inline-flex items-center justify-center px-10 py-5 font-black text-white bg-white/5 border border-white/10 rounded-[2rem] hover:bg-white/10 transition-all shadow-2xl overflow-hidden active:scale-95"
          >
            {loading ? (
              <Loader2 className="animate-spin mr-3" />
            ) : (
              <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/smartlock/icon_google.svg" className="w-6 h-6 mr-4" />
            )}
            <span className="text-lg uppercase tracking-wider">Đăng nhập bằng Google</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20">
          {[
            { icon: Zap, title: "Siêu Tốc", desc: "Quét hàng nghìn bài viết trong vài giây" },
            { icon: Cpu, title: "Trí Tuệ Nhân Tạo", desc: "Viết lại content chuẩn Viral bằng Gemini 2.0" },
            { icon: TrendingUp, title: "Dữ Liệu Thật", desc: "Thống kê tương tác chính xác 100%" }
          ].map((feat, i) => (
            <div key={i} className="p-8 bg-white/5 border border-white/10 rounded-3xl text-left backdrop-blur-md">
              <feat.icon className="text-blue-400 mb-4" size={24} />
              <h3 className="text-white font-bold mb-2">{feat.title}</h3>
              <p className="text-gray-500 text-sm leading-relaxed">{feat.desc}</p>
            </div>
          ))}
        </div>
      </div>
      
      <div className="mt-20 text-gray-600 text-[10px] font-bold uppercase tracking-widest">
        © 2025 FB SPY AI CORE SYSTEM. ALL RIGHTS RESERVED.
      </div>
    </div>
  );
};

const App: React.FC = () => {
  // --- Auth State ---
  const [user, setUser] = useState<User | null>(() => {
    const savedUser = localStorage.getItem('fb_spy_current_user');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  const [activeView, setActiveView] = useState<ViewType>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [inputMode, setInputMode] = useState<InputMode>('single');
  const [scanUrl, setScanUrl] = useState('');
  const [bulkScanUrls, setBulkScanUrls] = useState('');
  const [scanMode, setScanMode] = useState<ScanMode>('quick');
  const [displayMode, setDisplayMode] = useState<DisplayMode>('grid');
  const [isScanning, setIsScanning] = useState(false);
  const [scanStatus, setScanStatus] = useState('');
  const [scanResults, setScanResults] = useState<ScanResult | null>(null);
  const [library, setLibrary] = useState<LibraryItem[]>([]);
  const [analyzingPostId, setAnalyzingPostId] = useState<string | null>(null);
  const [toast, setToast] = useState<{message: string, type: 'success' | 'error' | 'info'} | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [scanHistory, setScanHistory] = useState<string[]>([]);
  const [scannedProfilesCount, setScannedProfilesCount] = useState(0);

  const [aiInput, setAiInput] = useState('');
  const [aiOutput, setAiOutput] = useState('');
  const [isWriting, setIsWriting] = useState(false);
  const [writingTone, setWritingTone] = useState<WritingTone>('viral');

  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedSearchQuery, setDebouncedSearchQuery] = useState('');
  const [activeTheme, setActiveTheme] = useState('classic');
  const [ideaNiche, setIdeaNiche] = useState('');

  const currentTheme = THEME_PRESETS[activeTheme] || THEME_PRESETS.classic;

  // --- Scoped Data Loading ---
  useEffect(() => {
    if (!user) return;
    
    // Lưu thông tin user
    localStorage.setItem('fb_spy_current_user', JSON.stringify(user));
    
    // Tải dữ liệu cụ thể cho user này
    const userId = user.id;
    const savedLib = localStorage.getItem(`fb_spy_lib_${userId}`);
    if (savedLib) setLibrary(JSON.parse(savedLib));
    
    const savedHist = localStorage.getItem(`fb_spy_hist_${userId}`);
    if (savedHist) setScanHistory(JSON.parse(savedHist));

    const count = localStorage.getItem(`fb_spy_count_${userId}`);
    if (count) setScannedProfilesCount(parseInt(count));
  }, [user]);

  useEffect(() => {
    const h = setTimeout(() => setDebouncedSearchQuery(searchQuery), 300);
    return () => clearTimeout(h);
  }, [searchQuery]);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => setToast({ message, type });

  const handleLogin = (newUser: User) => {
    setUser(newUser);
    showToast(`Chào mừng trở lại, ${newUser.name}!`, 'success');
  };

  const handleLogout = () => {
    localStorage.removeItem('fb_spy_current_user');
    setUser(null);
    setLibrary([]);
    setScanHistory([]);
    setScanResults(null);
    setActiveView('dashboard');
  };

  const persistUserData = (key: string, data: any) => {
    if (user) {
      localStorage.setItem(`fb_spy_${key}_${user.id}`, JSON.stringify(data));
    }
  };

  const handleScan = async () => {
    if (!user) return;
    const rawUrls = inputMode === 'single' ? [scanUrl.trim()] : bulkScanUrls.split('\n').map(u => u.trim()).filter(u => u !== '');
    if (rawUrls.length === 0) return showToast("Nhập URL!", 'error');

    const updatedHistory = Array.from(new Set([...rawUrls, ...scanHistory])).slice(0, 20);
    setScanHistory(updatedHistory);
    persistUserData('hist', updatedHistory);

    setIsScanning(true);
    try {
      setScanStatus('Đang kết nối API...');
      await new Promise(r => setTimeout(r, 1500));
      // Mocking results...
      const author = rawUrls[0].split('/').pop() || "Đối thủ";
      const posts: FBPost[] = Array.from({ length: 12 }).map((_, i) => ({
        id: `p-${user.id}-${Math.random()}`,
        content: `Bài viết mẫu ${i+1} dành riêng cho tài khoản ${user.email}...`,
        author,
        likes: Math.floor(Math.random() * 5000),
        comments: Math.floor(Math.random() * 1000),
        shares: Math.floor(Math.random() * 500),
        timestamp: new Date().toISOString(),
        url: rawUrls[0]
      }));
      setScanResults({ posts, profileName: author, totalEngagement: 5000, averageEngagement: 450 });
      setScannedProfilesCount(c => {
        const nc = c + rawUrls.length;
        if (user) localStorage.setItem(`fb_spy_count_${user.id}`, nc.toString());
        return nc;
      });
      setIsScanning(false);
      setActiveView('spy');
    } catch (e) {
      setIsScanning(false);
      showToast("Lỗi quét dữ liệu.", 'error');
    }
  };

  const saveToLibrary = (post: FBPost) => {
    if (library.some(p => p.id === post.id)) return showToast('Đã lưu rồi!', 'info');
    const updated = [{ ...post, savedAt: new Date().toISOString(), tags: ['viral'] }, ...library];
    setLibrary(updated);
    persistUserData('lib', updated);
    showToast('Đã lưu vào thư viện riêng!', 'success');
  };

  if (!user) return <LoginScreen onLogin={handleLogin} />;

  const NavItem = ({ icon: Icon, label, id }: { icon: any, label: string, id: ViewType }) => (
    <button onClick={() => setActiveView(id)} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${activeView === id ? 'text-white shadow-lg shadow-blue-500/20' : 'text-gray-500 hover:bg-gray-50'}`} style={{ backgroundColor: activeView === id ? currentTheme.primary : 'transparent' }}>
      <Icon size={18} />
      {isSidebarOpen && <span className="font-bold text-sm tracking-tight">{label}</span>}
    </button>
  );

  return (
    <div className="flex min-h-screen bg-gray-50">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      
      {/* Sidebar Nâng cấp */}
      <aside className={`${isSidebarOpen ? 'w-64' : 'w-20'} bg-white border-r border-gray-100 fixed h-full z-50 transition-all flex flex-col shadow-sm`}>
        <div className="p-6 flex items-center space-x-3">
          <div className="p-2.5 rounded-2xl text-white shadow-xl" style={{ backgroundColor: currentTheme.primary }}><Facebook size={22} /></div>
          {isSidebarOpen && <h1 className="text-xl font-black tracking-tighter">FB SPY <span className="text-blue-600">AI</span></h1>}
        </div>
        
        <nav className="flex-1 px-4 space-y-1.5 mt-4">
          <NavItem icon={LayoutDashboard} label="Bảng điều khiển" id="dashboard" />
          <NavItem icon={Search} label="Quét bài viết" id="scanner" />
          <NavItem icon={Sparkles} label="Ý tưởng Viral" id="idea-bank" />
          <NavItem icon={Zap} label="Kết quả Spy" id="spy" />
          <NavItem icon={Library} label="Thư viện cá nhân" id="library" />
          <NavItem icon={PenTool} label="AI Writer" id="ai-writer" />
        </nav>

        {/* User Profile Section */}
        <div className="p-4 border-t border-gray-50">
          <div className={`flex items-center ${isSidebarOpen ? 'space-x-3' : 'justify-center'} p-2 rounded-2xl bg-gray-50/50`}>
            <img src={user.avatar} className="w-9 h-9 rounded-xl border-2 border-white shadow-sm" />
            {isSidebarOpen && (
              <div className="flex-1 overflow-hidden">
                <p className="text-[11px] font-black uppercase tracking-widest text-gray-400">Tài khoản</p>
                <p className="text-xs font-bold text-gray-900 truncate">{user.name}</p>
              </div>
            )}
            {isSidebarOpen && (
              <button onClick={handleLogout} className="p-2 text-gray-400 hover:text-red-500 transition-colors" title="Đăng xuất">
                <LogOut size={16} />
              </button>
            )}
          </div>
          {!isSidebarOpen && (
            <button onClick={handleLogout} className="mt-4 w-full flex justify-center text-gray-400 hover:text-red-500">
              <LogOut size={18} />
            </button>
          )}
        </div>
      </aside>

      <main className={`${isSidebarOpen ? 'ml-64' : 'ml-20'} flex-1 p-8 transition-all`}>
        {activeView === 'dashboard' && (
          <div className="space-y-8 animate-in fade-in">
            <div className="flex justify-between items-end">
              <div>
                <h2 className="text-4xl font-black uppercase tracking-tighter">Chào {user.name.split(' ').pop()}!</h2>
                <p className="text-gray-400 font-medium">Dưới đây là thống kê tài khoản cá nhân của bạn.</p>
              </div>
              <div className="bg-white px-6 py-3 rounded-2xl border border-gray-100 flex items-center space-x-3 shadow-sm">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                <span className="text-xs font-black uppercase tracking-widest text-gray-500">Hệ thống AI Online</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                { label: 'Của riêng bạn', val: scannedProfilesCount, icon: UserIcon, color: 'text-blue-500' },
                { label: 'Thư viện', val: library.length, icon: Library, color: 'text-purple-500' },
                { label: 'Dung lượng', val: '0.2 / 5GB', icon: Database, color: 'text-emerald-500' },
                { label: 'AI Tokens', val: '850/1000', icon: Cpu, color: 'text-orange-500' }
              ].map((stat, i) => (
                <div key={i} className="p-8 bg-white rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-md transition-all">
                  <stat.icon className={`mb-4 ${stat.color}`} size={24} />
                  <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest">{stat.label}</p>
                  <p className="text-3xl font-black mt-1 tracking-tighter">{stat.val}</p>
                </div>
              ))}
            </div>
            
            <div className="p-10 bg-white rounded-[3rem] border border-gray-100 shadow-sm">
              <h3 className="text-xl font-black mb-8 uppercase tracking-tight">Xu hướng tương tác gần đây</h3>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={FORMAT_ANALYSIS_DATA}>
                    <defs>
                      <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/><stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/></linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 700}} />
                    <YAxis hide />
                    <Tooltip contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}} />
                    <Area type="monotone" dataKey="val" stroke="#3b82f6" strokeWidth={3} fill="url(#colorVal)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {activeView === 'scanner' && (
          <div className="max-w-2xl mx-auto space-y-8 animate-in slide-in-from-bottom-5">
            <div className="bg-white p-12 rounded-[3.5rem] shadow-sm border border-gray-100">
              <div className="text-center mb-10">
                <div className="inline-block p-4 bg-blue-50 rounded-3xl text-blue-600 mb-4"><Search size={32}/></div>
                <h2 className="text-3xl font-black uppercase tracking-tighter">Bắt đầu quét</h2>
                <p className="text-gray-400 text-sm font-medium mt-2">Dữ liệu sẽ được lưu riêng vào tài khoản <strong>{user.email}</strong></p>
              </div>
              <div className="space-y-6">
                <div className="relative">
                  <input className="w-full p-6 bg-gray-50 border-2 border-gray-50 rounded-3xl focus:border-blue-400 focus:bg-white outline-none transition-all font-bold text-lg" placeholder="Dán link Facebook đối thủ..." value={scanUrl} onChange={(e) => setScanUrl(e.target.value)} />
                  <Facebook className="absolute right-6 top-1/2 -translate-y-1/2 text-gray-200" size={24} />
                </div>
                <button onClick={handleScan} disabled={isScanning} className="w-full text-white py-6 rounded-3xl font-black text-lg uppercase tracking-widest shadow-xl shadow-blue-500/20 hover:brightness-110 active:scale-95 transition-all flex justify-center items-center" style={{ backgroundColor: currentTheme.primary }}>
                  {isScanning ? <><Loader2 className="animate-spin mr-3" /> {scanStatus}</> : 'PHÂN TÍCH NGAY'}
                </button>
              </div>
            </div>
          </div>
        )}

        {(activeView === 'spy' || activeView === 'library') && (
          <div className="space-y-6 animate-in fade-in">
            <header className="flex justify-between items-center bg-white p-6 rounded-[2.5rem] border border-gray-100">
              <h2 className="text-2xl font-black uppercase tracking-tighter">{activeView === 'spy' ? (scanResults?.profileName || 'Kết quả') : `Thư viện (${library.length})`}</h2>
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <SearchIcon size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" />
                  <input className="pl-10 pr-4 py-2.5 bg-gray-50 border-none rounded-2xl text-xs font-bold w-64 outline-none focus:ring-2 ring-blue-100" placeholder="Tìm trong kết quả..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
                </div>
                <button onClick={() => setDisplayMode(displayMode === 'grid' ? 'list' : 'grid')} className="p-2.5 bg-gray-50 text-gray-400 rounded-xl hover:text-blue-600 transition-colors">
                  {displayMode === 'grid' ? <List size={18}/> : <LayoutGrid size={18}/>}
                </button>
              </div>
            </header>

            <div className={displayMode === 'grid' ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" : "flex flex-col gap-6"}>
              {(activeView === 'spy' ? scanResults?.posts : library)?.filter(p => p.content.toLowerCase().includes(debouncedSearchQuery.toLowerCase())).map((post) => (
                <div key={post.id} className="bg-white p-8 rounded-[3rem] border border-gray-100 relative group hover:shadow-xl transition-all">
                  <div className="flex items-center mb-6 gap-4">
                    <div className="w-12 h-12 bg-gray-100 rounded-2xl flex items-center justify-center font-black text-gray-400 text-lg uppercase">{post.author.charAt(0)}</div>
                    <div>
                      <h4 className="font-black text-sm uppercase">{post.author}</h4>
                      <p className="text-[10px] font-black text-gray-300 uppercase tracking-widest">{new Date(post.timestamp).toLocaleDateString()}</p>
                    </div>
                    {activeView === 'spy' && (
                      <button onClick={() => saveToLibrary(post)} className="ml-auto p-3 text-gray-300 hover:text-blue-600 hover:bg-blue-50 rounded-2xl transition-all">
                        <Bookmark size={20} fill={library.some(p => p.id === post.id) ? "currentColor" : "none"} />
                      </button>
                    )}
                  </div>
                  <p className="text-gray-600 text-sm font-medium mb-8 leading-relaxed line-clamp-4">{post.content}</p>
                  
                  <div className="grid grid-cols-3 gap-4 pt-6 border-t border-gray-50">
                    <div className="text-center">
                      <p className="text-xs font-black">{post.likes.toLocaleString()}</p>
                      <p className="text-[9px] font-black uppercase text-gray-300">Likes</p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs font-black">{post.comments.toLocaleString()}</p>
                      <p className="text-[9px] font-black uppercase text-gray-300">Cmt</p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs font-black">{post.shares.toLocaleString()}</p>
                      <p className="text-[9px] font-black uppercase text-gray-300">Share</p>
                    </div>
                  </div>

                  <div className="mt-6 flex gap-3">
                    <button onClick={() => { setAiInput(post.content); setActiveView('ai-writer'); }} className="flex-1 py-3.5 bg-gray-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-black transition-all">Viết lại bằng AI</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* --- View khác tương tự --- */}
        {activeView === 'ai-writer' && (
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-[calc(100vh-10rem)] animate-in fade-in">
             <div className="bg-white p-10 rounded-[3rem] border border-gray-100 flex flex-col">
               <h2 className="text-2xl font-black mb-6 uppercase tracking-tighter">Biên tập AI</h2>
               <textarea className="flex-1 w-full p-6 bg-gray-50 border-none rounded-3xl resize-none mb-6 outline-none font-medium leading-relaxed" placeholder="Dán nội dung cần biến đổi..." value={aiInput} onChange={(e) => setAiInput(e.target.value)} />
               <button onClick={async () => { 
                 setIsWriting(true); 
                 const res = await rewritePost(aiInput, writingTone);
                 setAiOutput(res || ""); 
                 setIsWriting(false);
                 showToast('Đã tối ưu xong!', 'success');
               }} disabled={isWriting || !aiInput} className="w-full text-white py-5 rounded-3xl font-black uppercase tracking-widest shadow-lg transition-all" style={{ backgroundColor: currentTheme.primary }}>
                 {isWriting ? <Loader2 className="animate-spin inline mr-2"/> : <Zap className="inline mr-2" size={18}/>}
                 {isWriting ? 'Đang sáng tạo...' : 'Tối ưu ngay'}
               </button>
             </div>
             <div className="bg-white p-10 rounded-[3rem] border border-gray-100 flex flex-col relative overflow-hidden">
                <div className="absolute top-0 right-0 p-6 opacity-5"><Sparkles size={120}/></div>
                <h2 className="text-2xl font-black mb-6 uppercase tracking-tighter text-blue-600">Bản thảo hoàn thiện</h2>
                <div className="flex-1 w-full p-8 bg-gray-50 border-none rounded-3xl overflow-y-auto whitespace-pre-wrap font-medium leading-relaxed">
                  {aiOutput || <div className="h-full flex flex-col items-center justify-center text-gray-300 italic opacity-50"><PenTool size={48}/><p className="mt-4">Nội dung sau khi tối ưu sẽ hiện tại đây</p></div>}
                </div>
                {aiOutput && (
                  <button onClick={() => { navigator.clipboard.writeText(aiOutput); showToast('Đã copy!'); }} className="mt-6 flex items-center justify-center gap-3 py-4 bg-gray-900 text-white rounded-2xl font-black uppercase text-xs hover:bg-black transition-all">
                    <Copy size={16}/> Sao chép kết quả
                  </button>
                )}
             </div>
           </div>
        )}
      </main>
    </div>
  );
};

export default App;
