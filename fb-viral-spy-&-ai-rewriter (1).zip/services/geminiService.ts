
import { GoogleGenAI, Type } from "@google/genai";

const cleanJsonString = (text: string): string => {
  if (!text) return "{}";
  return text.replace(/^```json\s*/, "").replace(/^```\s*/, "").replace(/\s*```$/, "");
};

export const rewritePost = async (originalContent: string, tone: string = "viral", customPersona: string = "", keywords: string = "") => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  let systemInstruction = `Bạn là một chuyên gia Content Marketing và chuyên gia về thuật toán Facebook.`;
  if (customPersona.trim()) {
    systemInstruction += ` Hãy đóng vai: "${customPersona}".`;
  }
  
  const toneInstructions: Record<string, string> = {
    viral: "Viết ngắn gọn, gây sốc, bắt trend, dùng nhiều icon.",
    professional: "Viết trang trọng, đáng tin cậy, tập trung vào số liệu và chuyên môn.",
    funny: "Viết hài hước, mặn mòi, dùng tiếng lóng Gen Z, gây cười.",
    storytelling: "Viết dạng kể chuyện (Storytelling), tâm tình, dẫn dắt cảm xúc.",
    urgent: "Tạo cảm giác khẩn cấp (FOMO), thôi thúc hành động ngay lập tức.",
    emotional: "Viết sâu sắc, chạm đến nỗi đau hoặc niềm vui thầm kín, đồng cảm.",
    controversial: "Đưa ra quan điểm trái chiều, kích thích tranh luận văn minh."
  };

  systemInstruction += ` Phong cách: ${toneInstructions[tone] || tone}. Tự động loại bỏ các từ bị Facebook quét giảm tương tác (như "mua", "bán", "giá", "liên hệ", "số điện thoại" - hãy viết lách sang các từ đồng nghĩa hoặc thêm ký tự đặc biệt).`;

  const prompt = `
    Nhiệm vụ: Viết lại nội dung bài viết Facebook để tối ưu Viral và KHÔNG VI PHẠM chính sách.
    
    Yêu cầu:
    1. Hook hấp dẫn ở đầu.
    2. CTA khéo léo.
    3. Tránh các từ khóa bị bóp reach.
    ${keywords ? `4. Lồng ghép từ khóa: "${keywords}".` : ""}

    Nội dung gốc:
    "${originalContent}"
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.8,
      }
    });
    return response.text || "";
  } catch (error) {
    console.error("AI Error:", error);
    return "Lỗi khi gọi AI. Vui lòng kiểm tra API Key.";
  }
};

export const analyzeViralFactor = async (postContent: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `
    Phân tích bài viết Facebook sau để tìm lỗi và tối ưu.
    
    Bài viết: "${postContent}"
    
    Yêu cầu đặc biệt: Tìm các từ vi phạm chính sách Facebook (từ cấm, từ bóp reach) và lỗi chính tả.
    
    Hãy trả về JSON gồm:
    - viralScore (0-10): Điểm khả năng viral.
    - hookScore (0-10): Điểm câu mở đầu.
    - emotion (string): Cảm xúc chủ đạo.
    - strengths (array string): 3 điểm mạnh.
    - weakness (string): 1 điểm yếu.
    - policyWarnings (array string): Liệt kê các từ/nội dung có thể bị FB bóp tương tác hoặc vi phạm.
    - grammarCheck (string): Nhận xét về lỗi chính tả hoặc lỗi hành văn.
    - improvement (string): Lời khuyên sửa lỗi.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            viralScore: { type: Type.NUMBER },
            hookScore: { type: Type.NUMBER },
            emotion: { type: Type.STRING },
            strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
            weakness: { type: Type.STRING },
            policyWarnings: { type: Type.ARRAY, items: { type: Type.STRING } },
            grammarCheck: { type: Type.STRING },
            improvement: { type: Type.STRING }
          },
          required: ["viralScore", "hookScore", "emotion", "strengths", "weakness", "policyWarnings", "grammarCheck", "improvement"]
        }
      }
    });
    
    const text = cleanJsonString(response.text || "{}");
    return JSON.parse(text);
  } catch (error) {
    console.error("Analysis Error:", error);
    return null;
  }
};

export const generateViralIdeas = async (niche: string, keywords: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `Tạo 5 ý tưởng bài viết Facebook cho ngành "${niche}" với từ khóa "${keywords}". Trả về JSON ARRAY.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              content: { type: Type.STRING },
              viralReason: { type: Type.STRING },
              category: { type: Type.STRING }
            },
            required: ["title", "content", "viralReason", "category"]
          }
        }
      }
    });
    const text = cleanJsonString(response.text || "[]");
    return JSON.parse(text);
  } catch (error) {
    return [];
  }
};
